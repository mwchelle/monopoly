/*
  Speed Monopoly CPT
  Jonathan Chen, Kevin Hu, Michelle Wan
  ICS4U1b
  26/01/2022
*/

/*
  Creates a menu to run and play the game
*/
class Main {
  public static void main(String[] args) {
    Game monopoly = new Game();
    monopoly.menu();
  }
}